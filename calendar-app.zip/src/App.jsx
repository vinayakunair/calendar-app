import React, { useState } from 'react';
import dayjs from 'dayjs';
import './App.css';

const App = () => {
  const [currentDate, setCurrentDate] = useState(dayjs());

  const events = [
    { date: '2025-05-08', title: 'Meeting with team', time: '14:00', duration: '1h' },
    { date: '2025-05-08', title: 'Doctor Appointment', time: '14:30', duration: '30m' },
    { date: '2025-05-09', title: 'Birthday Party', time: '18:00', duration: '3h' }
  ];

  const startDay = currentDate.startOf('month').startOf('week');
  const endDay = currentDate.endOf('month').endOf('week');
  const daysArray = [];
  let day = startDay;

  while (day.isBefore(endDay)) {
    daysArray.push(day);
    day = day.add(1, 'day');
  }

  const goToPrevMonth = () => setCurrentDate(currentDate.subtract(1, 'month'));
  const goToNextMonth = () => setCurrentDate(currentDate.add(1, 'month'));

  const isToday = (day) => day.isSame(dayjs(), 'day');

  const getEventsForDate = (date) => {
    const formatted = date.format('YYYY-MM-DD');
    return events.filter((event) => event.date === formatted);
  };

  return (
    <div className="app">
      <h1>Calendar App</h1>

      <div className="calendar-header">
        <button onClick={goToPrevMonth}>◀</button>
        <h2>{currentDate.format('MMMM YYYY')}</h2>
        <button onClick={goToNextMonth}>▶</button>
      </div>

      <div className="calendar-grid">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
          <div className="day-name" key={day}>{day}</div>
        ))}

        {daysArray.map((date, idx) => (
          <div
            key={idx}
            className={`calendar-cell ${isToday(date) ? 'today' : ''} ${date.month() !== currentDate.month() ? 'disabled' : ''}`}
          >
            <div className="day-number">{date.date()}</div>
            {getEventsForDate(date).map((event, i) => (
              <div key={i} className="event">
                <strong>{event.title}</strong><br />
                {event.time} ({event.duration})
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
